import 'package:flutter/material.dart';

// COLORS
class AppColors {
  static Color darkBlue = const Color(0xff131429);
  static Color green = const Color(0xff40D876);
}
