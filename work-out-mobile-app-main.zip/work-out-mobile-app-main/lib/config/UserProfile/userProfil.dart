
// dummy profile stats
class UserProfileStats {
     static List stats = [
    {
      "title": "achievs",
      "value": "25",
    },
    {
      "title": "badges",
      "value": "3",
    },
    {
      "title": "workouts",
      "value": "5",
    },
  ];
}