
// to-do: correct spells, search for more texts in app if I forget to add them here
class AppTexts {
  static String error = "Error";
  static String firstMainWord = "hard";
  static String secondaryMainWord = "element";
  static String welcome = "welcome";
  static String welcomeDescription =
      "This is a workout app that will help you to get fit and stay fit.";
  static String getStarted = "get started";
  static String login = "login";
  static String changeLaungage = "change laungage";
  static String chooseLaungage = "choose laungage";
  static String primaryLaungage = "en";
  static String secondaryLaungage = "fr";
  static String aboutYou = "about you";
  static String getStartedDescription =
      "we want to know more about you, follow the next steps to complete the information";
  static String skipIntro = "Skip intro";
  static String next = "Next";
  static String signIn = "sign in";
  static String signUp = "sign up";
  static String loginDescription =
      "Train and live the new experience of exercising at home";
  static String email = "email";
  static String password = "password";
  static String forgetPassword = "forgot password ?";
  static String forgot = "forgot?";
  static String resetPassword = "reset $password";
  static String yourEmail = "your $email";
  static String forgotPasswordDesccription =
      "DON'T WORRY, WE CAN HELP YOU TO RESET YOUR PASSWORD";
  static String emailSentText =
      "We have sent you an email to verify your account. Please check your inbox and click the link to verify it";
  static String done = "done";
  static String reSendEmailVerification = "re-send email verification";
  static String signUpDescription =
      "Join more than 100,000 warriors and train for the next big challenge";
  static String username = "username";
  static String alreadyHaveAnAccount = "Already have an account ?";
  static String find = "find";
  static String yourWorkout = 'your Workout';
  static String filterBy = "Filter by :";
  static String cancel = "Cancel";
  static String apply = "Apply";
  static String configureSettings = "configure profile";

  static String hours = "hours";
  static String moves = "moves";
  static String sets = "sets";
  static String minutes = "min";
  static String freeTrial = "free trial";
  static String noFreeTrialAvailable = "No preview available";
  static String searchWorkout = "Search workout";
  static String seeAll = 'see all';
  static String somethingWrong = "something wrong";
  static String hey = "Hey,";

  static String profile = "profile";
  static String logOut = "log out";
  static String workoutOfDay = "Workout of the day";
  static String withDiscounts = 'with discounts';
  static String basedOnReviews = "based on users reviews";
  static String dailyFreeWorkout = "Workout of the day";
  static String choosedCarefully = "choosed carefully";
  static String allWorkouts = 'all workouts';
  static String pleaseVerifyEmail = "Please verify your email first";
  static String enterEmail = "please enter your email";
  static String enterValidEmail = "please enter a valid email";
  static String emailVerifSentText =
      "we've sent you an email to reset your password, check your inbox";
  static String noUserText = "there is no user with this email";
  static String checkConnection = 'check your internet connection';
  static String wrongPassword = "wrong password";
  static String invalidEmail = "Invalid email address, try again";
  static String enterPassword = "Please enter your password";
  static String passwordMustBe5AtLeast = "Password must be at least 5 characters long";
  static String usernameMustBe5AtLeast =
      "username must be at least 5 characters long";
  static String weakPassword = "weak password, try with stronger one";
  static String emailAlreadyInUse = "this email is already in use";
  static String fillFields =  "please, fill all fields";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";
  // static String basedOnReviews = "based on users reviews";

}
