// Search filter options

List filtersItemsFromFile = [
  {
    "isChecked": false,
    "title": "All threads",
    "description": "All",
  },
  {
    "isChecked": false,
    "title": "Strength",
    "description": "Strength",
  },
  {
    "isChecked": false,
    "title": "Cardio",
    "description": "Cardio",
  },
  {
    "isChecked": false,
    "title": "Yoga",
    "description": "Yoga",
  },
  {
    "isChecked": false,
    "title": "Pilates",
    "description": "Pilates",
  },
  {
    "isChecked": false,
    "title": "Other",
    "description": "Other",
  },
];
