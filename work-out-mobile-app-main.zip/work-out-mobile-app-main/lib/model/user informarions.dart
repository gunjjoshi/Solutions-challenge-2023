
class AppUserInfo {
// this is temporary
 
}
