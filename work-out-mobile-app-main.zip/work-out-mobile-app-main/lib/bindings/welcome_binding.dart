import 'package:get/get.dart';


class WelcomePageBinding implements Bindings {
  @override
  void dependencies() {
    // Dependency injection
    // Get.put<FunctionsController>(FunctionsController());
  }
}
