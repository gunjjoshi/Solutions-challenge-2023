import 'package:get/get.dart';

class ForgotPasswordBinding implements Bindings {
@override
void dependencies() {
 
  }
}